// RecentlyReachedFragment.java

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_recently_reached, container, false);
    progressBar = view.findViewById(R.id.progressBar);
    recyclerView = view.findViewById(R.id.recyclerView);
    backButton = view.findViewById(R.id.backButton);
    backButton.setOnClickListener(this);
    recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
    database = Database.getInstance(getContext());

    readUserData();
    return view;
}
// RecentlyReachedFragment.java

private void readUserData() {
    showLoading();
    database.readUsersData(new Database.GeneralCallback() {

        @Override
        public void onSuccess() {
            updateRecentReachedItems();
        }

        @Override
        public void onFailure(int errorCode, String errorMessage) {
            hideLoading();
            Toast.makeText(getContext(), errorMessage, Toast.LENGTH_SHORT).show();
        }
    });

}
// RecentlyReachedFragment.java

private void updateRecentReachedItems() {
    database.updateRecentPosts(new Database.RecentUpdateCallback() {
        @Override
        public void onSuccess(List<HashMap<String, String>> reachedItems) {
            fetchAndDisplayRecentReachedPosts(reachedItems);
        }

        @Override
        public void onFailure(int errorCode, String errorMessage) {
            hideLoading();
            Toast.makeText(getContext(), "No recently reached items.", Toast.LENGTH_SHORT).show();
        }
    });

}
// RecentlyReachedFragment.java

private void fetchAndDisplayRecentReachedPosts(final List<HashMap<String, String>> reachedItems) {
    database.displayRecentPosts(reachedItems, new Database.RecentDisplayCallback() {

        @Override
        public void onSuccess(HashMap<String, HashMap<String, String>> recentReachedPosts) {
            sortAndShowRecentReachedPosts(recentReachedPosts);
        }

        @Override
        public void onFailure(int errorCode, String errorMessage) {
            hideLoading();
            Toast.makeText(getContext(), errorMessage, Toast.LENGTH_SHORT).show();
        }
    });

}

// RecentlyReachedFragment.java

private void sortAndShowRecentReachedPosts(HashMap<String, HashMap<String, String>> recentReachedPosts) {

    List<HashMap.Entry<String, HashMap<String, String>>> list = new ArrayList<>(recentReachedPosts.entrySet());
    list.sort(new Comparator<HashMap.Entry<String, HashMap<String, String>>>() {
        @Override
        public int compare(HashMap.Entry<String, HashMap<String, String>> o1, HashMap.Entry<String, HashMap<String, String>> o2) {

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            try {
                Date date1 = dateFormat.parse(o1.getValue().get("Date"));
                Date date2 = dateFormat.parse(o2.getValue().get("Date"));
                return date2.compareTo(date1);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return 0;
        }
    });

    HashMap<String, HashMap<String, String>> sortedRecentReachedPosts = new HashMap<>();
    for (HashMap.Entry<String, HashMap<String, String>> entry : list) {
        sortedRecentReachedPosts.put(entry.getKey(), entry.getValue());
    }

    hideLoading();
    ReachAdapter adapter = new ReachAdapter(sortedRecentReachedPosts);
    recyclerView.setAdapter(adapter);
}

// Database.java

public void displayRecentPosts(final List<HashMap<String, String>> list, RecentDisplayCallback callback) {
    final HashMap<String, HashMap<String, String>> recentPosts = new HashMap<>();
    postsReference.addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                for (DataSnapshot postSnapshot : userSnapshot.getChildren()) {
                    String postId = postSnapshot.getKey();
                    for (HashMap<String, String> posts : list) {
                        if (postId.equals(posts.get("Post Id"))) {
                            HashMap<String, String> postDetails = (HashMap<String, String>) postSnapshot.child("Property Details").getValue();
                            if (postDetails != null) {
                                String userId = userSnapshot.getKey();
                                for (HashMap<String, Object> userMap : userList) {
                                    if (userMap.get("id").equals(userId)) {
                                        postDetails.put("userName", userMap.get("firstName") + " " + userMap.get("lastName"));
                                        postDetails.put("phoneNumber", userMap.get("phoneNumber") + "");
                                        if (callback.toString().contains("RecentlyViewedFragment")) {
                                            postDetails.put("Date", posts.get("Date"));
                                        }
                                        break;
                                    }
                                }
                                DataSnapshot photosSnapshot = postSnapshot.child("Photos");
                                if (photosSnapshot.exists()) {
                                    for (DataSnapshot photoSnapshot : photosSnapshot.getChildren()) {
                                        postDetails.put("photoUrl", photoSnapshot.getValue(String.class));
                                        break;
                                    }
                                }
                                postDetails.put("Date", posts.get("Date"));
                                recentPosts.put(postId, postDetails);
                            }
                        }
                    }
                }
            }
            callback.onSuccess(recentPosts);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
            callback.onFailure(0, "Failed to read post value: " + databaseError.getMessage());
        }
    });
}


