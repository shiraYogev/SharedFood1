package com.example.wiserent;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Source;

import java.util.Timer;
import java.util.TimerTask;

public class RentedHomePage extends AppCompatActivity {

    /**
     * רכיב TextView שמציג את שם המשתמש המלא.
     * הוספת תיעוד זה נועדה לשפר את קריאות הקוד ולסייע למפתחים חדשים להבין את ייעוד המשתנה.
     */
    private TextView fullName;
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;
    private String userID;
    private Button bLogOutBtn, bNewAppealBtn, bpaymentBtn, bnewLeaseReqBtn, bTrackingAppealsBtn;
    private ImageButton bUserBtn;
    private User user, userObj;
    private Timer leaseCheckTimer;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rented_home_page);

        initializeUI(); // הוצאת אתחול רכיבי ה-UI לפונקציה נפרדת כדי לשפר את הקריאות ולהקטין כפילות קוד

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (value != null && value.exists()) {
                    user = value.toObject(User.class);
                    fullName.setText(user.getFullName());
                } else {
                    fullName.setText("User not found");
                }
            }
        });

        startLeaseCheckTimer();
    }

    /**
     * פונקציה נפרדת לאתחול רכיבי ה-UI
     * משפרת את הקריאות, מפחיתה כפילות קוד, ומאפשרת קריאות קלה יותר לפיתוח עתידי.
     */
    private void initializeUI() {
        fullName = findViewById(R.id.Name);
        bLogOutBtn = findViewById(R.id.logoutBtn);
        bUserBtn = findViewById(R.id.userBtn);
        bNewAppealBtn = findViewById(R.id.newAppealBtn);
        bpaymentBtn = findViewById(R.id.paymentBtn);
        bnewLeaseReqBtn = findViewById(R.id.newLeaseReqBtn);
        bTrackingAppealsBtn = findViewById(R.id.trackingAppealsBtn);
    }

    /**
     * פונקציה לשיפור שליפת חוזים מ-Firestore.
     * נוספה בדיקת Null כדי למנוע קריסות אם userObj לא מאותחל.
     * נעשה שימוש ב-Source.CACHE כדי להפחית שאילתות חוזרות ל-Firestore ולשפר את הביצועים.
     */
    private void checkForLeaseUpdates() {
        if (userObj == null || userObj.getUserId() == null) {
            Log.e("RentedHomePage", "User object is null");
            return;
        }

        fStore.collection("leases")
                .whereEqualTo("rentedId", userObj.getUserId())
                .get(Source.CACHE) // שימוש בזיכרון מטמון להפחתת השאילתות
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (DocumentSnapshot document : task.getResult()) {
                            Lease lease = document.toObject(Lease.class);
                            if (lease != null && lease.isStatus()) {
                                boolean check = true;
                                for (Lease property : userObj.getLeasedProperties()) {
                                    if (property.getLeaseId().equals(lease.getLeaseId())) {
                                        check = false;
                                    }
                                }
                                if (check) {
                                    updateLeaseList(lease);
                                }
                            }
                        }
                    } else {
                        Log.e("RentedHomePage", "Error getting leases: ", task.getException());
                    }
                });
    }

    /**
     * סינכרון עדכון חוזים כדי למנוע Race Condition.
     * שימוש ב-synchronized כדי לוודא שרק Thread אחד מבצע את העדכון בו-זמנית.
     */
    private void updateLeaseList(Lease lease) {
        synchronized (userObj) {
            userObj.addLease(lease);
        }
        handler.post(() -> {
            Toast.makeText(RentedHomePage.this, "חוזה אושר", Toast.LENGTH_LONG).show();
            fStore.collection("users")
                    .document(userObj.getUserId())
                    .set(userObj)
                    .addOnSuccessListener(unused -> Log.d("RentedHomePage", "Successfully added to User Collection"))
                    .addOnFailureListener(e -> Log.e("RentedHomePage", "Failed to add to User Collection: " + e.toString()));
        });
    }

    /**
     * שיפור פונקציית היציאה כך שתנקה את מחסנית הפעילויות ולא תאפשר חזרה לאחור.
     */
    public void logout(View view) {
        fAuth.signOut();
        Intent intent = new Intent(getApplicationContext(), Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    /**
     * הוספת בדיקה למניעת יצירת טיימר נוסף אם כבר רץ.
     * מונע הקצאת משאבים מיותרת ושומר על ביצועים מיטביים.
     */
    private void startLeaseCheckTimer() {
        if (leaseCheckTimer == null) {
            leaseCheckTimer = new Timer();
            leaseCheckTimer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    checkForLeaseUpdates();
                }
            }, 0, 60000);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (leaseCheckTimer != null) {
            leaseCheckTimer.cancel();
        }
    }
}
